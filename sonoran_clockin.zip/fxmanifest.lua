fx_version 'cerulean'
game 'gta5'

author 'Sonoran Software'
version '1.0.1'
git_repo 'https://github.com/Sonoran-Software/sonoran_clockin'

server_script 'sv_clockin.js'
client_script 'cl_clockin.js'